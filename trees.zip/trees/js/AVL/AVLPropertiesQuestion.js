class AVLPropertiesQuestion
{
    constructor(main)
    {
        this.main=main;
        
        //selects value from radio button in from with assocoiated value
        this.radio=document.querySelector('[qtype_name="AVL"]');
        this.CategorySelector=document.querySelector('[]');
        console.log("Hello","hello");
    }
}